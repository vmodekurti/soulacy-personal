<script>
  export let provider = ''
  export let model = ''
  export let providers = []
  export let writable = false
  export let optional = false
</script>
<label>Provider<select bind:value={provider} disabled={!writable}><option value="">{optional ? 'Inherit default' : 'Deployment default'}</option>{#each providers as id}<option value={id}>{id}</option>{/each}</select></label>
<label>Model<input bind:value={model} placeholder={optional ? 'Inherit provider model' : 'Provider default model'} disabled={!writable} /></label>
<style>label{display:grid;gap:6px;color:#cdd1e8;font-size:12px;margin-top:9px}input,select{width:100%;box-sizing:border-box;background:#15192b;color:#f2f3ff;border:1px solid #303655;border-radius:8px;padding:9px}</style>
